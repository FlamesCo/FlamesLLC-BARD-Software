import tkinter as tk
import urllib.request
import os

class TorrentDownloader(tk.Tk):
    def __init__(self):
        super().__init__()

        # Set the window title
        self.title("FT-TRACKER 0.X.A [C] @FlamesLLC Downloader")
## [C] - Flames LLC 20XX-20XX
        # Set the window size
        self.geometry("600x400")

        # Create a frame for the torrent file input
        self.torrent_file_frame = tk.Frame(self)

        # Create a label for the torrent file input
        self.torrent_file_label = tk.Label(self.torrent_file_frame, text="Torrent File:")

        # Create a text box for the torrent file input
        self.torrent_file_entry = tk.Entry(self.torrent_file_frame)

        # Create a frame for the download button
        self.download_button_frame = tk.Frame(self)

        # Create a button to start the download
        self.download_button = tk.Button(self.download_button_frame, text="Download", command=self.start_download)

        # Layout the widgets
        self.torrent_file_frame.pack(side="left", fill="both", expand=True)
        self.torrent_file_label.pack(in_=self.torrent_file_frame, side="left", padx=5, pady=5)
        self.torrent_file_entry.pack(in_=self.torrent_file_frame, side="left", fill="x", expand=True)
        self.download_button_frame.pack(side="right", fill="both", expand=True)
        self.download_button.pack(in_=self.download_button_frame, side="bottom", fill="x", expand=True)

    def start_download(self):
        # Get the torrent file path from the input
        torrent_file_path = self.torrent_file_entry.get()

        # Check if the torrent file exists
        if not os.path.exists(torrent_file_path):
            print("The torrent file does not exist.")
            return

        # Download the torrent file
        with open(torrent_file_path, "rb") as f:
            urllib.request.urlretrieve("https://example.com/" + torrent_file_path, torrent_file_path)

        print("The torrent file has been downloaded.")

if __name__ == "__main__":
    app = TorrentDownloader()
    app.mainloop()
